// Nexus Manager API (Vercel Function). One endpoint: POST /api  { a: "login" | "push" | "pull" | ... }
const { neon } = require('@neondatabase/serverless');
const crypto = require('crypto');

const sql = neon(process.env.DATABASE_URL || process.env.POSTGRES_URL || '');
const SECRET = process.env.AUTH_SECRET || '';
const KINDS_ALL = ['shop', 'eq', 'price', 'doc', 'srv', 'terms'];
const KINDS_STAFF = ['shop', 'eq'];
let ready = null;

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const same = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
const b64 = s => Buffer.from(s).toString('base64url');
const mac = d => crypto.createHmac('sha256', SECRET).update(d).digest('base64url');
const sign = p => { const d = b64(JSON.stringify(p)); return d + '.' + mac(d); };
function verify(t) {
  const [d, s] = String(t || '').split('.');
  if (!d || !s || !same(mac(d), s)) return null;
  try { const p = JSON.parse(Buffer.from(d, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch (e) { return null; }
}

function init() {
  if (!ready) {
    ready = (async () => {
      await sql`create table if not exists users(email text primary key, name text, role text not null default 'staff', salt text not null, hash text not null)`;
      await sql`create table if not exists records(id text primary key, kind text not null, data jsonb not null default '{}', deleted boolean not null default false, updated_at timestamptz not null default clock_timestamp())`;
      await sql`create index if not exists records_u on records(updated_at, id)`;
      const n = await sql`select count(*)::int as c from users`;
      const em = (process.env.ADMIN_EMAIL || '').trim().toLowerCase(), pw = process.env.ADMIN_PASSWORD || '';
      if (!n[0].c && em && pw) {
        const salt = crypto.randomBytes(16).toString('hex');
        await sql`insert into users(email, name, role, salt, hash) values(${em}, 'Owner', 'admin', ${salt}, ${hashPw(pw, salt)})`;
      }
    })();
    ready.catch(() => { ready = null; });
  }
  return ready;
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  try {
    if (SECRET.length < 16) return res.status(500).json({ error: 'Server setup missing: set AUTH_SECRET (16+ characters) in Vercel Environment Variables' });
    await init();
    const b = req.body || {}, a = b.a;

    if (a === 'login') {
      const em = String(b.email || '').trim().toLowerCase();
      const r = (await sql`select email, name, role, salt, hash from users where email = ${em}`)[0];
      if (!r || !same(hashPw(String(b.password || ''), r.salt), r.hash)) {
        await new Promise(z => setTimeout(z, 600));
        return res.status(401).json({ error: 'bad' });
      }
      return res.json({ token: sign({ email: em, exp: Date.now() + 30 * 864e5 }), user: { email: em, name: r.name, role: r.role } });
    }

    const p = verify((req.headers.authorization || '').slice(7));
    const u = p && (await sql`select email, name, role from users where email = ${p.email}`)[0];
    if (!u) return res.status(401).json({ error: 'auth' });
    const adm = u.role === 'admin', kinds = adm ? KINDS_ALL : KINDS_STAFF;

    if (a === 'push') {
      const up = Array.isArray(b.up) ? b.up : [];
      const ok = up.every(r => r && typeof r.id === 'string' && kinds.includes(r.kind) && r.id.startsWith(r.kind + ':'));
      if (!ok) return res.status(403).json({ error: 'Not allowed' });
      if (up.length) {
        await sql`insert into records(id, kind, data, deleted, updated_at)
          select x->>'id', x->>'kind', coalesce(x->'data', '{}'::jsonb), coalesce((x->>'deleted')::boolean, false), clock_timestamp()
          from jsonb_array_elements(${JSON.stringify(up)}::jsonb) x
          on conflict (id) do update set kind = excluded.kind, data = excluded.data, deleted = excluded.deleted, updated_at = excluded.updated_at`;
      }
      return res.json({ ok: 1 });
    }

    if (a === 'pull') {
      const since = String(b.since || '1970-01-01T00:00:00Z'), after = String(b.after || '');
      const rows = await sql`select id, kind, data, deleted, updated_at::text as updated_at from records
        where kind = any(string_to_array(${kinds.join(',')}::text, ',')) and (updated_at, id) > (${since}::timestamptz, ${after}::text)
        order by updated_at, id limit 300`;
      const out = []; let sz = 0;
      for (const r of rows) { sz += JSON.stringify(r).length; if (out.length && sz > 3000000) break; out.push(r); }
      return res.json({ rows: out, more: out.length < rows.length || rows.length === 300 });
    }

    if (a === 'password') {
      const pw = String(b.password || '');
      if (pw.length < 6) return res.status(400).json({ error: 'Password too short' });
      const salt = crypto.randomBytes(16).toString('hex');
      await sql`update users set salt = ${salt}, hash = ${hashPw(pw, salt)} where email = ${u.email}`;
      return res.json({ ok: 1 });
    }

    if (!adm) return res.status(403).json({ error: 'Admin only' });
    const em = String(b.email || '').trim().toLowerCase();

    if (a === 'staffList') return res.json({ rows: await sql`select email, name, role from users order by email` });

    if (a === 'staffAdd') {
      const pw = String(b.password || ''), role = b.role === 'admin' ? 'admin' : 'staff';
      if (!em || pw.length < 6) return res.status(400).json({ error: 'Email and a 6+ character password are required' });
      const salt = crypto.randomBytes(16).toString('hex');
      await sql`insert into users(email, name, role, salt, hash) values(${em}, ${String(b.name || em)}, ${role}, ${salt}, ${hashPw(pw, salt)})
        on conflict (email) do update set name = excluded.name, role = excluded.role, salt = excluded.salt, hash = excluded.hash`;
      return res.json({ ok: 1 });
    }

    if (a === 'staffRole') {
      const role = b.role === 'admin' ? 'admin' : 'staff';
      if (role !== 'admin') {
        const c = await sql`select count(*)::int as c from users where role = 'admin' and email <> ${em}`;
        if (!c[0].c) return res.status(400).json({ error: 'Keep at least one admin' });
      }
      await sql`update users set role = ${role} where email = ${em}`;
      return res.json({ ok: 1 });
    }

    if (a === 'staffDel') {
      if (em === u.email) return res.status(400).json({ error: 'You cannot delete yourself' });
      await sql`delete from users where email = ${em}`;
      return res.json({ ok: 1 });
    }

    return res.status(400).json({ error: 'Unknown action' });
  } catch (e) {
    return res.status(500).json({ error: String((e && e.message) || e) });
  }
};
